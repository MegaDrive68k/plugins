
function initJobFilter() {
	//console.log(rundeckPage.path());
	if(rundeckPage.path() === "scheduledExecution/show"){
			var checkExist = setInterval(function() {
		   if (jQuery('[name="extra.option.'+rootOption+'"]').length) {
		      clearInterval(checkExist);
		      filterSSHUSR();
		      jQuery('[name="extra.option.'+rootOption+'"]')[0].setAttribute("onchange", "filterSSHUSR()");
		   }
		}, 100); 
	}
}


var rootOption = 'family';
var childOption = 'ssh_usr';
var hideValue = 'windows.json';



function filterSSHUSR(){
	if(jQuery('[name="extra.option.'+childOption+'"]').size()==1){
		var input1 = jQuery('[name="extra.option.'+childOption+'"]')[0];
		if(jQuery('[name="extra.option.'+rootOption+'"]')[0].value==hideValue){
			jQuery(input1).closest('.form-group')[0].hidden=true;
		}else{
			jQuery(input1).closest('.form-group')[0].hidden=false;
		}
	}
}